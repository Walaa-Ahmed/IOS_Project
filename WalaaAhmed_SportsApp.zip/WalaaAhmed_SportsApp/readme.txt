Team members : Walaa Ahmed Abdelhamid Mohammed  - Mobile_Alex_iOS_Project-Team6

folder contains : 
1) compressed project folder
2) ScreenShot of Sports App Project